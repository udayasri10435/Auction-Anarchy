import express from 'express';
import http from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import path from 'path';
import { fileURLToPath } from 'url';
import { AuctionLot, WSMessage, ClientMessage, Collectible, BidRecord, ChatMessage } from './src/types';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

app.use(express.json());

// Initial Seed Digital Collectibles
const seedCollectibles: Collectible[] = [
  {
    id: 'art-001',
    title: 'KAGE-09: CYBER RONIN',
    series: 'Neo-Edo Syndicate',
    edition: '01/01',
    description: 'Autonomous neural blade master forged in the underbelly of Neo-Tokyo. Features hyper-frequency vibration katana and dynamic optical refraction.',
    rarity: 'CHAOS',
    visualTheme: 'cyber-samurai',
    visualSeed: 914,
    traits: [
      { label: 'Blade Resonance', value: '98.4 GHz', rarityPercent: 2 },
      { label: 'Neuro-Sync', value: 'Overclocked', rarityPercent: 5 },
      { label: 'Armor Alloy', value: 'Vibro-Titanium', rarityPercent: 12 },
      { label: 'Glitch Factor', value: '44.8%', rarityPercent: 8 },
    ],
    creatorName: 'KuroNeko_AI',
    creatorAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=KuroNeko',
    tokenHash: '0x9c48b2...a8f1',
  },
  {
    id: 'art-002',
    title: 'SOL DEITY ASCENSION',
    series: 'Celestial Pantheon',
    edition: '03/05',
    description: 'Gold-plated solar entity manifesting in deep cosmic obsidian. Casts blinding geometric flares upon market turbulence.',
    rarity: 'MYTHIC',
    visualTheme: 'sol-deity',
    visualSeed: 777,
    traits: [
      { label: 'Radiance', value: '1.2M Lumens', rarityPercent: 4 },
      { label: 'Halo Facets', value: '16 Prisms', rarityPercent: 7 },
      { label: 'Origin', value: 'Kardashev II', rarityPercent: 1 },
      { label: 'Solar Mass', value: '4.8 x 10^30 kg', rarityPercent: 9 },
    ],
    creatorName: 'Aethelgard',
    creatorAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=Aethelgard',
    tokenHash: '0x3f12c8...d41b',
  },
  {
    id: 'art-003',
    title: 'NEON DRIFTER: RX-SPEC',
    series: 'Midnight Grid Run',
    edition: '08/10',
    description: 'Supersonic twin-turbine drift interceptor with reactive aerodynamic chassis and dual emerald phase-lasers.',
    rarity: 'LEGENDARY',
    visualTheme: 'neon-drifter',
    visualSeed: 304,
    traits: [
      { label: 'Top Velocity', value: '620 km/h', rarityPercent: 14 },
      { label: 'Downforce', value: '3,800 N', rarityPercent: 22 },
      { label: 'Underglow', value: 'Phase Emerald', rarityPercent: 18 },
      { label: 'Tuning Stage', value: 'Stage 4 Anarchy', rarityPercent: 6 },
    ],
    creatorName: 'ApexSynthetics',
    creatorAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=Apex',
    tokenHash: '0x7e29aa...194c',
  },
  {
    id: 'art-004',
    title: 'THE VOID MONOLITH',
    series: 'Hyper-Dimensions',
    edition: '01/03',
    description: 'Gravitational anomaly encased in non-Euclidean obsidian crystalline matrix. Warps time within bidding radius.',
    rarity: 'MYTHIC',
    visualTheme: 'void-monolith',
    visualSeed: 555,
    traits: [
      { label: 'Dimensional Depth', value: '4.5D', rarityPercent: 3 },
      { label: 'Event Horizon', value: 'Stable', rarityPercent: 8 },
      { label: 'Resonant Spin', value: 'Anti-Clockwise', rarityPercent: 15 },
    ],
    creatorName: 'NullSector',
    creatorAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=NullSector',
    tokenHash: '0x1a88bb...773f',
  },
  {
    id: 'art-005',
    title: 'PUNK-666: PROTOCOL BREAKER',
    series: 'Decentral Punks',
    edition: '01/01',
    description: 'The iconic rebel consciousness that breached the central ledger. Equipped with spikes, visor HUD, and pure chaotic energy.',
    rarity: 'CHAOS',
    visualTheme: 'pixel-punk',
    visualSeed: 666,
    traits: [
      { label: 'Anarchy Level', value: '99/100', rarityPercent: 1 },
      { label: 'Hair Spike Density', value: 'High Poly', rarityPercent: 6 },
      { label: 'Visor HUD', value: 'Overload Mode', rarityPercent: 11 },
    ],
    creatorName: 'VandalsCollective',
    creatorAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=Vandal',
    tokenHash: '0xee9100...b299',
  },
];

let activeLots: AuctionLot[] = [];
let recentChat: ChatMessage[] = [
  {
    id: 'c-init-1',
    userId: 'system',
    userName: 'AUCTION MASTER',
    userAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=AuctionMaster',
    text: '⚡ Live war floor initialized. Anti-snipe shields enabled (+15s on sub-10s bids). Place your bids!',
    timestamp: Date.now() - 30000,
    isSystemAnnouncement: true,
  },
];

// Initialize lots
function initLots() {
  const now = Date.now();
  activeLots = [
    {
      id: 'lot-1',
      collectible: seedCollectibles[0],
      type: 'BLITZ',
      startingPrice: 1500,
      currentPrice: 2200,
      minIncrement: 100,
      highestBidderId: 'bot-1',
      highestBidderName: 'CryptoViper',
      highestBidderAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=Viper',
      bids: [
        {
          id: 'bid-1',
          bidderId: 'bot-2',
          bidderName: 'SatoshiGhost',
          bidderAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=Satoshi',
          amount: 1800,
          timestamp: now - 25000,
        },
        {
          id: 'bid-2',
          bidderId: 'bot-1',
          bidderName: 'CryptoViper',
          bidderAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=Viper',
          amount: 2200,
          timestamp: now - 12000,
        },
      ],
      status: 'ACTIVE',
      startsAt: now - 35000,
      endsAt: now + 45000, // 45s left
      durationSeconds: 80,
      snipeExtensionsCount: 0,
    },
    {
      id: 'lot-2',
      collectible: seedCollectibles[1],
      type: 'DUTCH',
      startingPrice: 9000,
      currentPrice: 7200,
      minIncrement: 0,
      highestBidderId: null,
      highestBidderName: null,
      highestBidderAvatar: null,
      bids: [],
      status: 'ACTIVE',
      startsAt: now - 36000,
      endsAt: now + 120000,
      durationSeconds: 156,
      snipeExtensionsCount: 0,
      dutchFloorPrice: 2500,
      dutchDecayPerSec: 50,
    },
    {
      id: 'lot-3',
      collectible: seedCollectibles[2],
      type: 'SEALED_DUEL',
      startingPrice: 3000,
      currentPrice: 3000,
      minIncrement: 200,
      highestBidderId: null,
      highestBidderName: null,
      highestBidderAvatar: null,
      bids: [],
      blindBidsCount: 3,
      status: 'ACTIVE',
      startsAt: now - 20000,
      endsAt: now + 70000,
      durationSeconds: 90,
      snipeExtensionsCount: 0,
    },
    {
      id: 'lot-4',
      collectible: seedCollectibles[3],
      type: 'BLITZ',
      startingPrice: 4000,
      currentPrice: 4000,
      minIncrement: 250,
      highestBidderId: null,
      highestBidderName: null,
      highestBidderAvatar: null,
      bids: [],
      status: 'UPCOMING',
      startsAt: now + 30000,
      endsAt: now + 110000,
      durationSeconds: 80,
      snipeExtensionsCount: 0,
    },
  ];
}

initLots();

// Track connected sockets
const clients = new Set<WebSocket>();

function broadcast(msg: WSMessage) {
  const data = JSON.stringify(msg);
  for (const client of clients) {
    if (client.readyState === WebSocket.OPEN) {
      client.send(data);
    }
  }
}

// Tick loop (every 1 second)
setInterval(() => {
  const now = Date.now();
  let changed = false;

  for (const lot of activeLots) {
    // Check if upcoming lot starts
    if (lot.status === 'UPCOMING' && now >= lot.startsAt) {
      lot.status = 'ACTIVE';
      changed = true;
    }

    // Dutch Decay price decrease
    if (lot.status === 'ACTIVE' && lot.type === 'DUTCH' && lot.dutchDecayPerSec && lot.dutchFloorPrice) {
      if (lot.currentPrice > lot.dutchFloorPrice) {
        lot.currentPrice = Math.max(lot.dutchFloorPrice, lot.currentPrice - lot.dutchDecayPerSec);
        changed = true;
      }
    }

    // Check ending soon or ended
    if (lot.status === 'ACTIVE' || lot.status === 'ENDING_SOON') {
      const remainingSecs = Math.max(0, Math.floor((lot.endsAt - now) / 1000));
      if (remainingSecs <= 10 && lot.status === 'ACTIVE') {
        lot.status = 'ENDING_SOON';
        changed = true;
      }

      // Check if auction time is up
      if (now >= lot.endsAt) {
        lot.status = lot.highestBidderId ? 'SOLD' : 'ENDED';
        changed = true;

        const winner = lot.highestBidderName || 'None';
        const finalPrice = lot.currentPrice;

        if (lot.highestBidderName) {
          lot.winnerDeclared = {
            winnerName: lot.highestBidderName,
            winningAmount: finalPrice,
          };
        }

        broadcast({
          type: 'HAMMER_DROP',
          payload: {
            lotId: lot.id,
            winnerName: winner,
            finalPrice,
            lot,
          },
        });

        // Add announcement chat
        const announceMsg: ChatMessage = {
          id: `ann-${Date.now()}`,
          userId: 'system',
          userName: 'HAMMER DROP',
          userAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=Hammer',
          text: `🔨 GAVEL STRIKE: "${lot.collectible.title}" SOLD to ${winner} for $${finalPrice.toLocaleString()}!`,
          timestamp: Date.now(),
          isSystemAnnouncement: true,
        };
        recentChat.push(announceMsg);
        if (recentChat.length > 50) recentChat.shift();
        broadcast({ type: 'NEW_CHAT', payload: announceMsg });

        // Auto spin up next lot replacement after 5 seconds if fewer than 3 active lots
        setTimeout(() => {
          recycleAndAddNewLot(lot.id);
        }, 5000);
      }
    }
  }

  if (changed) {
    broadcast({
      type: 'LOTS_UPDATE',
      payload: {
        lots: activeLots,
        serverTime: now,
      },
    });
  }
}, 1000);

// Rotate / replenish lots to keep auction alive forever
function recycleAndAddNewLot(endedLotId: string) {
  const index = activeLots.findIndex((l) => l.id === endedLotId);
  if (index === -1) return;

  const now = Date.now();
  const themePool: Collectible['visualTheme'][] = [
    'cyber-samurai',
    'sol-deity',
    'neon-drifter',
    'void-monolith',
    'pixel-punk',
  ];
  const chosenTheme = themePool[Math.floor(Math.random() * themePool.length)];
  const rarities: Collectible['rarity'][] = ['RARE', 'LEGENDARY', 'MYTHIC', 'CHAOS'];
  const chosenRarity = rarities[Math.floor(Math.random() * rarities.length)];

  const seriesNames = ['Anarchy Protocol', 'Cyber Ronin Syndicate', 'Void Glitchers', 'HyperDrive V2'];
  const chosenSeries = seriesNames[Math.floor(Math.random() * seriesNames.length)];

  const randomId = `art-${Date.now().toString().slice(-4)}`;
  const newCollectible: Collectible = {
    id: randomId,
    title: `GENESIS ARTIFACT #${Math.floor(Math.random() * 899 + 100)}`,
    series: chosenSeries,
    edition: `01/0${Math.floor(Math.random() * 5 + 1)}`,
    description: 'Freshly synthesized neural artifact minted directly into the live frenzy ring. Verified high-frequency cryptographic signature.',
    rarity: chosenRarity,
    visualTheme: chosenTheme,
    visualSeed: Math.floor(Math.random() * 10000),
    traits: [
      { label: 'Anarchy Quotient', value: `${(Math.random() * 40 + 60).toFixed(1)}%`, rarityPercent: 5 },
      { label: 'Core Frequency', value: `${Math.floor(Math.random() * 800 + 200)} MHz`, rarityPercent: 10 },
      { label: 'Security Class', value: 'Unrestricted', rarityPercent: 15 },
    ],
    creatorName: 'AnarchyDAO',
    creatorAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=AnarchyDAO',
    tokenHash: `0x${Math.random().toString(16).substring(2, 8)}...${Math.random().toString(16).substring(2, 6)}`,
  };

  const types: AuctionLot['type'][] = ['BLITZ', 'BLITZ', 'DUTCH', 'SEALED_DUEL'];
  const auctionType = types[Math.floor(Math.random() * types.length)];
  const startPrice = Math.floor(Math.random() * 30 + 10) * 100;

  const newLot: AuctionLot = {
    id: `lot-${Date.now()}`,
    collectible: newCollectible,
    type: auctionType,
    startingPrice: startPrice,
    currentPrice: auctionType === 'DUTCH' ? startPrice * 3 : startPrice,
    minIncrement: Math.round(startPrice * 0.05),
    highestBidderId: null,
    highestBidderName: null,
    highestBidderAvatar: null,
    bids: [],
    status: 'ACTIVE',
    startsAt: now,
    endsAt: now + (auctionType === 'DUTCH' ? 120000 : 75000),
    durationSeconds: auctionType === 'DUTCH' ? 120 : 75,
    snipeExtensionsCount: 0,
    dutchFloorPrice: auctionType === 'DUTCH' ? startPrice : undefined,
    dutchDecayPerSec: auctionType === 'DUTCH' ? 40 : undefined,
  };

  // Replace ended lot
  activeLots[index] = newLot;

  broadcast({
    type: 'NEW_LOT_LAUNCHED',
    payload: newLot,
  });

  const launchMsg: ChatMessage = {
    id: `c-launch-${Date.now()}`,
    userId: 'system',
    userName: 'AUCTION FLOOR',
    userAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=Floor',
    text: `⚡ NEW AUCTION DROPPED: "${newCollectible.title}" (${auctionType}) is LIVE on the floor!`,
    timestamp: Date.now(),
    isSystemAnnouncement: true,
  };
  recentChat.push(launchMsg);
  if (recentChat.length > 50) recentChat.shift();
  broadcast({ type: 'NEW_CHAT', payload: launchMsg });
}

// WebSocket Connection Management
wss.on('connection', (ws) => {
  clients.add(ws);

  // Send initial state
  const initMsg: WSMessage = {
    type: 'INIT',
    payload: {
      lots: activeLots,
      activeUsers: Math.max(12, clients.size * 3 + 7), // Realistic lively lobby presence
      recentChat,
      serverTime: Date.now(),
    },
  };
  ws.send(JSON.stringify(initMsg));

  // Broadcast user count
  broadcast({
    type: 'USER_PRESENCE',
    payload: { activeUsers: Math.max(12, clients.size * 3 + 7) },
  });

  ws.on('message', (data) => {
    try {
      const msg: ClientMessage = JSON.parse(data.toString());

      if (msg.type === 'PLACE_BID') {
        const { lotId, amount, user } = msg.payload;
        const lot = activeLots.find((l) => l.id === lotId);

        if (!lot) {
          ws.send(JSON.stringify({ type: 'BID_ERROR', payload: { lotId, reason: 'Auction lot not found.' } }));
          return;
        }

        if (lot.status !== 'ACTIVE' && lot.status !== 'ENDING_SOON') {
          ws.send(JSON.stringify({ type: 'BID_ERROR', payload: { lotId, reason: 'Auction has already ended.' } }));
          return;
        }

        const requiredMin = lot.currentPrice + (lot.bids.length === 0 ? 0 : lot.minIncrement);
        if (amount < requiredMin) {
          ws.send(JSON.stringify({ type: 'BID_ERROR', payload: { lotId, reason: `Bid too low! Minimum required is $${requiredMin.toLocaleString()}` } }));
          return;
        }

        const now = Date.now();
        const secondsRemaining = (lot.endsAt - now) / 1000;
        let snipeTriggered = false;

        // ANTI-SNIPE DEFENSE: If bid arrives in last 10 seconds, add +15 seconds!
        if (secondsRemaining <= 10) {
          lot.endsAt = now + 15000; // extend clock by 15s from right now
          lot.snipeExtensionsCount += 1;
          lot.status = 'ACTIVE'; // resets out of ENDING_SOON danger state
          snipeTriggered = true;
        }

        const newBid: BidRecord = {
          id: `bid-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          bidderId: user.id,
          bidderName: user.name,
          bidderAvatar: user.avatar,
          amount,
          timestamp: now,
          isSnipe: snipeTriggered,
        };

        lot.currentPrice = amount;
        lot.highestBidderId = user.id;
        lot.highestBidderName = user.name;
        lot.highestBidderAvatar = user.avatar;
        lot.bids.unshift(newBid);

        broadcast({
          type: 'BID_ACCEPTED',
          payload: {
            lotId: lot.id,
            lot,
            bid: newBid,
            snipeTriggered,
          },
        });

        // Add auto chat notice on sniper
        if (snipeTriggered) {
          const snipeMsg: ChatMessage = {
            id: `c-snipe-${Date.now()}`,
            userId: 'system',
            userName: 'SNIPE DEFENSE',
            userAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=SnipeShield',
            text: `⚡ ANTI-SNIPE SHIELD ACTIVATED! ${user.name} bid $${amount.toLocaleString()} at the wire! +15 SECONDS ADDED!`,
            timestamp: now,
            isSystemAnnouncement: true,
          };
          recentChat.push(snipeMsg);
          if (recentChat.length > 50) recentChat.shift();
          broadcast({ type: 'NEW_CHAT', payload: snipeMsg });
        }
      }

      if (msg.type === 'CLAIM_DUTCH') {
        const { lotId, user } = msg.payload;
        const lot = activeLots.find((l) => l.id === lotId);
        if (!lot || lot.type !== 'DUTCH' || (lot.status !== 'ACTIVE' && lot.status !== 'ENDING_SOON')) {
          return;
        }

        lot.highestBidderId = user.id;
        lot.highestBidderName = user.name;
        lot.highestBidderAvatar = user.avatar;
        lot.status = 'SOLD';
        lot.endsAt = Date.now();
        lot.winnerDeclared = {
          winnerName: user.name,
          winningAmount: lot.currentPrice,
        };

        broadcast({
          type: 'HAMMER_DROP',
          payload: {
            lotId: lot.id,
            winnerName: user.name,
            finalPrice: lot.currentPrice,
            lot,
          },
        });

        const dutchClaimMsg: ChatMessage = {
          id: `c-dutch-${Date.now()}`,
          userId: 'system',
          userName: 'DUTCH SNIPED',
          userAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=DutchWin',
          text: `⚡ DUTCH CLAIMED! ${user.name} snapped "${lot.collectible.title}" at $${lot.currentPrice.toLocaleString()}!`,
          timestamp: Date.now(),
          isSystemAnnouncement: true,
        };
        recentChat.push(dutchClaimMsg);
        broadcast({ type: 'NEW_CHAT', payload: dutchClaimMsg });

        setTimeout(() => recycleAndAddNewLot(lot.id), 5000);
      }

      if (msg.type === 'SUBMIT_SEALED_BID') {
        const { lotId, amount, user } = msg.payload;
        const lot = activeLots.find((l) => l.id === lotId);
        if (!lot || lot.type !== 'SEALED_DUEL') return;

        lot.blindBidsCount = (lot.blindBidsCount || 0) + 1;
        // Keep highest sealed bid secretly tracked
        if (!lot.highestBidderId || amount > lot.currentPrice) {
          lot.currentPrice = amount;
          lot.highestBidderId = user.id;
          lot.highestBidderName = user.name;
          lot.highestBidderAvatar = user.avatar;
        }

        broadcast({
          type: 'LOTS_UPDATE',
          payload: {
            lots: activeLots,
            serverTime: Date.now(),
          },
        });

        const sealedMsg: ChatMessage = {
          id: `c-seal-${Date.now()}`,
          userId: 'system',
          userName: 'SEALED DUEL',
          userAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=Lock',
          text: `🔒 ${user.name} submitted a confidential blind bid into the vault! (${lot.blindBidsCount} sealed envelopes)`,
          timestamp: Date.now(),
          isSystemAnnouncement: true,
        };
        recentChat.push(sealedMsg);
        broadcast({ type: 'NEW_CHAT', payload: sealedMsg });
      }

      if (msg.type === 'SEND_CHAT') {
        const { text, reaction, user } = msg.payload;
        const newChat: ChatMessage = {
          id: `chat-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
          userId: user.id,
          userName: user.name,
          userAvatar: user.avatar,
          text,
          reaction,
          timestamp: Date.now(),
        };
        recentChat.push(newChat);
        if (recentChat.length > 50) recentChat.shift();
        broadcast({ type: 'NEW_CHAT', payload: newChat });
      }

      if (msg.type === 'MINT_AUCTION') {
        const { collectible, type, startingPrice, durationSeconds, user } = msg.payload;
        const now = Date.now();
        const createdCollectible: Collectible = {
          ...collectible,
          id: `art-user-${Date.now()}`,
          tokenHash: `0x${Math.random().toString(16).substring(2, 8)}...${Math.random().toString(16).substring(2, 6)}`,
        };

        const customLot: AuctionLot = {
          id: `lot-minted-${Date.now()}`,
          collectible: createdCollectible,
          type,
          startingPrice,
          currentPrice: startingPrice,
          minIncrement: Math.max(50, Math.round(startingPrice * 0.05)),
          highestBidderId: null,
          highestBidderName: null,
          highestBidderAvatar: null,
          bids: [],
          status: 'ACTIVE',
          startsAt: now,
          endsAt: now + durationSeconds * 1000,
          durationSeconds,
          snipeExtensionsCount: 0,
        };

        // Add to front of active lots
        activeLots.unshift(customLot);

        broadcast({
          type: 'NEW_LOT_LAUNCHED',
          payload: customLot,
        });

        const customMintMsg: ChatMessage = {
          id: `c-mint-${Date.now()}`,
          userId: 'system',
          userName: 'CREATOR DROP',
          userAvatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=Mint',
          text: `🚀 ${user.name} minted and listed "${customLot.collectible.title}" for a ${durationSeconds}s BLITZ auction!`,
          timestamp: now,
          isSystemAnnouncement: true,
        };
        recentChat.push(customMintMsg);
        broadcast({ type: 'NEW_CHAT', payload: customMintMsg });
      }
    } catch (err) {
      console.error('WebSocket message parsing error:', err);
    }
  });

  ws.on('close', () => {
    clients.delete(ws);
    broadcast({
      type: 'USER_PRESENCE',
      payload: { activeUsers: Math.max(12, clients.size * 3 + 7) },
    });
  });
});

// HTTP Endpoints
app.get('/api/status', (_req, res) => {
  res.json({ status: 'live', activeLotsCount: activeLots.length, clientsCount: clients.size });
});

app.get('/api/auctions', (_req, res) => {
  res.json({ lots: activeLots, serverTime: Date.now() });
});

// Vite or Static Hosting
async function setupVite() {
  const isProduction = process.env.NODE_ENV === 'production';
  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const PORT = process.env.PORT || 3000;
  server.listen(PORT, () => {
    console.log(`Auction Anarchy server listening on port ${PORT}`);
  });
}

setupVite();
