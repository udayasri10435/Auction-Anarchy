import React, { useRef, useState } from 'react';
import { Collectible, CollectibleRarity, VisualTheme } from '../types';
import { Sparkles, Shield, Cpu, Flame, Zap } from 'lucide-react';

interface Props {
  collectible: Collectible;
  size?: 'sm' | 'md' | 'lg' | 'hero';
  showDetails?: boolean;
  interactive?: boolean;
  isHighBid?: boolean;
}

export const CollectibleVisualizer: React.FC<Props> = ({
  collectible,
  size = 'md',
  showDetails = false,
  interactive = true,
  isHighBid = false,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [rotateX, setRotateX] = useState(0);
  const [rotateY, setRotateY] = useState(0);
  const [glarePos, setGlarePos] = useState({ x: 50, y: 50 });
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!interactive || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const px = (x / rect.width) * 100;
    const py = (y / rect.height) * 100;
    
    // Tilt angle -12 to +12 deg
    const rx = ((y / rect.height) - 0.5) * -20;
    const ry = ((x / rect.width) - 0.5) * 20;

    setRotateX(rx);
    setRotateY(ry);
    setGlarePos({ x: px, y: py });
  };

  const handleMouseLeave = () => {
    setRotateX(0);
    setRotateY(0);
    setIsHovered(false);
  };

  const rarityColor = (rarity: CollectibleRarity) => {
    switch (rarity) {
      case 'CHAOS':
        return {
          border: 'border-fuchsia-500/50',
          badge: 'bg-fuchsia-500/10 text-fuchsia-400 border-fuchsia-500/30',
          glow: 'rgba(217, 70, 239, 0.4)',
        };
      case 'MYTHIC':
        return {
          border: 'border-amber-500/50',
          badge: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
          glow: 'rgba(245, 158, 11, 0.4)',
        };
      case 'LEGENDARY':
        return {
          border: 'border-cyan-500/50',
          badge: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30',
          glow: 'rgba(6, 182, 212, 0.4)',
        };
      case 'RARE':
        return {
          border: 'border-emerald-500/50',
          badge: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
          glow: 'rgba(16, 185, 129, 0.4)',
        };
      default:
        return {
          border: 'border-zinc-700',
          badge: 'bg-zinc-800 text-zinc-300 border-zinc-700',
          glow: 'rgba(113, 113, 122, 0.2)',
        };
    }
  };

  const currentTheme = collectible.visualTheme;
  const colors = rarityColor(collectible.rarity);
  const seed = collectible.visualSeed || 42;

  // Render thematic procedural SVGs
  const renderThemeArtwork = () => {
    switch (currentTheme) {
      case 'cyber-samurai':
        return (
          <svg viewBox="0 0 400 400" className="w-full h-full object-cover">
            <defs>
              <linearGradient id={`cs-bg-${collectible.id}`} x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#0f0728" />
                <stop offset="50%" stopColor="#1a0b36" />
                <stop offset="100%" stopColor="#05030a" />
              </linearGradient>
              <linearGradient id={`cs-blade-${collectible.id}`} x1="0%" y1="100%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#06b6d4" />
                <stop offset="50%" stopColor="#ec4899" />
                <stop offset="100%" stopColor="#ffffff" />
              </linearGradient>
              <radialGradient id={`cs-glow-${collectible.id}`}>
                <stop offset="0%" stopColor="#ec4899" stopOpacity="0.8" />
                <stop offset="60%" stopColor="#06b6d4" stopOpacity="0.2" />
                <stop offset="100%" stopColor="transparent" />
              </radialGradient>
              <filter id={`cs-blur-${collectible.id}`}>
                <feGaussianBlur stdDeviation="8" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>

            {/* Background canvas */}
            <rect width="400" height="400" fill={`url(#cs-bg-${collectible.id})`} />
            
            {/* Cyber Kanji background watermark ring */}
            <circle cx="200" cy="180" r="130" fill="none" stroke="#3b0764" strokeWidth="2" strokeDasharray="6 8" />
            <circle cx="200" cy="180" r="100" fill="none" stroke="#06b6d4" strokeWidth="1" strokeOpacity="0.4" />
            
            {/* Aura glow */}
            <circle cx="200" cy="180" r="110" fill={`url(#cs-glow-${collectible.id})`} />

            {/* Cyber Helmet Silhouette */}
            <path
              d="M 140 180 L 160 110 L 200 80 L 240 110 L 260 180 L 250 250 L 200 270 L 150 250 Z"
              fill="#18181b"
              stroke="#06b6d4"
              strokeWidth="2.5"
            />
            {/* Kabuto horn crest */}
            <path
              d="M 200 80 L 170 30 L 200 55 L 230 30 Z"
              fill="#f59e0b"
              stroke="#fbbf24"
              strokeWidth="1.5"
            />
            {/* Visor Glitch Bar */}
            <rect x="160" y="155" width="80" height="14" rx="2" fill="#ec4899" filter={`url(#cs-blur-${collectible.id})`} />
            <rect x="165" y="157" width="70" height="10" rx="1" fill="#ffffff" />

            {/* Glowing Dual Katana Slits */}
            <path d="M 60 360 L 340 80" stroke={`url(#cs-blade-${collectible.id})`} strokeWidth="4" strokeLinecap="round" filter={`url(#cs-blur-${collectible.id})`} />
            <path d="M 60 360 L 340 80" stroke="#ffffff" strokeWidth="1.5" strokeLinecap="round" />

            {/* Particle spark coordinates derived from seed */}
            {Array.from({ length: 12 }).map((_, i) => {
              const cx = ((seed * (i + 3) * 17) % 360) + 20;
              const cy = ((seed * (i + 7) * 23) % 360) + 20;
              return (
                <circle
                  key={i}
                  cx={cx}
                  cy={cy}
                  r={(i % 3) + 1.2}
                  fill={i % 2 === 0 ? '#06b6d4' : '#ec4899'}
                  className="animate-pulse"
                  style={{ animationDelay: `${(i * 0.2).toFixed(1)}s` }}
                />
              );
            })}
          </svg>
        );

      case 'sol-deity':
        return (
          <svg viewBox="0 0 400 400" className="w-full h-full object-cover">
            <defs>
              <linearGradient id={`sd-bg-${collectible.id}`} x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#1e1005" />
                <stop offset="50%" stopColor="#080706" />
                <stop offset="100%" stopColor="#180e03" />
              </linearGradient>
              <linearGradient id={`gold-grad-${collectible.id}`} x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#fef08a" />
                <stop offset="50%" stopColor="#eab308" />
                <stop offset="100%" stopColor="#854d0e" />
              </linearGradient>
            </defs>

            <rect width="400" height="400" fill={`url(#sd-bg-${collectible.id})`} />

            {/* Celestial Sunburst halo */}
            {Array.from({ length: 16 }).map((_, i) => {
              const angle = (i * 360) / 16;
              return (
                <line
                  key={i}
                  x1="200"
                  y1="180"
                  x2={200 + Math.cos((angle * Math.PI) / 180) * 145}
                  y2={180 + Math.sin((angle * Math.PI) / 180) * 145}
                  stroke="#eab308"
                  strokeWidth="1.5"
                  strokeDasharray={i % 2 === 0 ? '4 8' : 'none'}
                  strokeOpacity="0.6"
                />
              );
            })}

            {/* Sacred Concentric Rings */}
            <circle cx="200" cy="180" r="120" fill="none" stroke="#ca8a04" strokeWidth="2" strokeOpacity="0.4" />
            <circle cx="200" cy="180" r="85" fill="none" stroke={`url(#gold-grad-${collectible.id})`} strokeWidth="3" />
            
            {/* Obsidian Celestial Mask */}
            <path
              d="M 160 140 C 160 110, 240 110, 240 140 C 240 210, 220 250, 200 265 C 180 250, 160 210, 160 140 Z"
              fill="#09090b"
              stroke={`url(#gold-grad-${collectible.id})`}
              strokeWidth="2"
            />
            {/* Third Eye Diamond */}
            <polygon points="200,140 207,150 200,160 193,150" fill="#facc15" />
            {/* Divine teardrop streaks */}
            <line x1="180" y1="185" x2="180" y2="230" stroke="#facc15" strokeWidth="1.5" strokeOpacity="0.8" />
            <line x1="220" y1="185" x2="220" y2="230" stroke="#facc15" strokeWidth="1.5" strokeOpacity="0.8" />
          </svg>
        );

      case 'neon-drifter':
        return (
          <svg viewBox="0 0 400 400" className="w-full h-full object-cover">
            <defs>
              <linearGradient id={`nd-bg-${collectible.id}`} x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#03120d" />
                <stop offset="100%" stopColor="#020806" />
              </linearGradient>
              <linearGradient id={`emerald-neon-${collectible.id}`} x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#10b981" />
                <stop offset="100%" stopColor="#06b6d4" />
              </linearGradient>
            </defs>

            <rect width="400" height="400" fill={`url(#nd-bg-${collectible.id})`} />

            {/* Neon Speed Grid Perspective */}
            <path d="M 200 120 L 0 380 M 200 120 L 100 380 M 200 120 L 200 380 M 200 120 L 300 380 M 200 120 L 400 380" stroke="#10b981" strokeWidth="1" strokeOpacity="0.3" />
            <ellipse cx="200" cy="280" rx="150" ry="40" fill="none" stroke="#10b981" strokeWidth="1.5" strokeOpacity="0.4" />

            {/* Isometric Drifter Chassis */}
            <path
              d="M 120 220 L 170 170 L 280 170 L 330 220 L 310 250 L 90 250 Z"
              fill="#09090b"
              stroke={`url(#emerald-neon-${collectible.id})`}
              strokeWidth="2.5"
            />
            {/* Cockpit canopy */}
            <path d="M 170 170 L 200 145 L 250 145 L 270 170 Z" fill="#042f2e" stroke="#10b981" strokeWidth="1.5" />
            {/* Laser Taillight Bar */}
            <line x1="100" y1="235" x2="300" y2="235" stroke="#ec4899" strokeWidth="3" strokeLinecap="round" />
            {/* Underglow Ground Reflection */}
            <ellipse cx="200" cy="265" rx="130" ry="12" fill="#10b981" fillOpacity="0.3" filter="blur(6px)" />
          </svg>
        );

      case 'void-monolith':
        return (
          <svg viewBox="0 0 400 400" className="w-full h-full object-cover">
            <defs>
              <linearGradient id={`vm-grad-${collectible.id}`} x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#7c3aed" />
                <stop offset="50%" stopColor="#2563eb" />
                <stop offset="100%" stopColor="#09090b" />
              </linearGradient>
            </defs>
            <rect width="400" height="400" fill="#05020c" />
            
            {/* Gravitational Distortion Rings */}
            <ellipse cx="200" cy="200" rx="140" ry="70" fill="none" stroke="#7c3aed" strokeWidth="1.5" strokeDasharray="5 7" transform="rotate(-25 200 200)" />
            <ellipse cx="200" cy="200" rx="100" ry="50" fill="none" stroke="#60a5fa" strokeWidth="1" strokeDasharray="3 5" transform="rotate(35 200 200)" />

            {/* Hyper-dimensional Crystal Core */}
            <polygon
              points="200,60 260,150 240,290 200,340 160,290 140,150"
              fill={`url(#vm-grad-${collectible.id})`}
              stroke="#a855f7"
              strokeWidth="2"
            />
            {/* Internal Facets */}
            <polygon points="200,60 200,340 160,290 140,150" fill="#4c1d95" fillOpacity="0.5" />
            <polygon points="200,60 260,150 200,200" fill="#38bdf8" fillOpacity="0.3" />
            <polygon points="200,200 260,150 240,290 200,340" fill="#6d28d9" fillOpacity="0.6" />

            {/* Pulsing singularity light */}
            <circle cx="200" cy="200" r="14" fill="#ffffff" filter="blur(2px)" />
          </svg>
        );

      case 'pixel-punk':
      default:
        return (
          <svg viewBox="0 0 400 400" className="w-full h-full object-cover">
            <defs>
              <linearGradient id={`pp-bg-${collectible.id}`} x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#180b22" />
                <stop offset="100%" stopColor="#0a050f" />
              </linearGradient>
            </defs>
            <rect width="400" height="400" fill={`url(#pp-bg-${collectible.id})`} />

            {/* Pixel Anarchy Glyph Grid */}
            <g transform="translate(60, 50)">
              {/* Spiked Hair block */}
              <rect x="70" y="30" width="30" height="70" fill="#ec4899" />
              <rect x="110" y="10" width="35" height="90" fill="#ec4899" />
              <rect x="155" y="40" width="30" height="60" fill="#ec4899" />

              {/* Head structure */}
              <rect x="60" y="100" width="160" height="150" fill="#27272a" />
              {/* Cyber Augmented Visor */}
              <rect x="50" y="130" width="180" height="40" fill="#06b6d4" />
              <rect x="60" y="135" width="70" height="30" fill="#facc15" />
              <rect x="150" y="135" width="70" height="30" fill="#facc15" />

              {/* Nose & Mouth */}
              <rect x="135" y="185" width="12" height="20" fill="#3f3f46" />
              <rect x="100" y="220" width="80" height="8" fill="#10b981" />

              {/* Distressed Spiked Collar */}
              <rect x="40" y="250" width="200" height="40" fill="#09090b" stroke="#71717a" strokeWidth="2" />
              <polygon points="60,250 70,230 80,250" fill="#e4e4e7" />
              <polygon points="110,250 120,230 130,250" fill="#e4e4e7" />
              <polygon points="160,250 170,230 180,250" fill="#e4e4e7" />
              <polygon points="210,250 220,230 230,250" fill="#e4e4e7" />
            </g>
          </svg>
        );
    }
  };

  const sizeClasses = {
    sm: 'w-24 h-24',
    md: 'w-56 h-56',
    lg: 'w-80 h-80',
    hero: 'w-full aspect-square max-w-[420px]',
  }[size];

  return (
    <div
      ref={containerRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={handleMouseLeave}
      className={`relative group select-none rounded-xl overflow-hidden transition-transform duration-150 ease-out ${sizeClasses} ${colors.border} border bg-zinc-950/80 shadow-2xl`}
      style={{
        transform: interactive
          ? `perspective(800px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(${isHovered ? 1.02 : 1}, ${isHovered ? 1.02 : 1}, 1)`
          : undefined,
        boxShadow: isHighBid
          ? `0 0 35px ${colors.glow}`
          : isHovered
          ? `0 10px 30px ${colors.glow}`
          : undefined,
      }}
    >
      {/* Visual Artwork */}
      <div className="w-full h-full relative">
        {renderThemeArtwork()}

        {/* Dynamic Holographic Glare Sheen */}
        {interactive && (
          <div
            className="absolute inset-0 pointer-events-none transition-opacity duration-200"
            style={{
              opacity: isHovered ? 0.35 : 0.08,
              background: `radial-gradient(circle 280px at ${glarePos.x}% ${glarePos.y}%, rgba(255, 255, 255, 0.8), transparent 70%)`,
              mixBlendMode: 'overlay',
            }}
          />
        )}

        {/* Scanline CRT overlay */}
        <div
          className="absolute inset-0 pointer-events-none opacity-20"
          style={{
            backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0, 0, 0, 0.6) 3px, rgba(0, 0, 0, 0.6) 4px)',
          }}
        />

        {/* Top Floating Token Tag */}
        <div className="absolute top-2.5 left-2.5 right-2.5 flex items-center justify-between pointer-events-none">
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded bg-black/70 backdrop-blur-md border border-white/10 text-[11px] font-mono tracking-wider text-zinc-300">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
            <span>#{collectible.edition}</span>
          </div>

          <div className={`px-2 py-0.5 rounded text-[10px] font-mono tracking-wider uppercase font-semibold border backdrop-blur-md ${colors.badge}`}>
            {collectible.rarity}
          </div>
        </div>

        {/* Bottom Title Bar overlay for sm/md views */}
        {showDetails && (
          <div className="absolute bottom-0 inset-x-0 p-3 bg-gradient-to-t from-black/95 via-black/80 to-transparent backdrop-blur-[2px]">
            <div className="text-xs font-mono text-zinc-400 truncate">{collectible.series}</div>
            <div className="text-sm font-bold text-white tracking-tight truncate">{collectible.title}</div>
          </div>
        )}
      </div>
    </div>
  );
};
