import React from 'react';
import { Volume2, VolumeX, PlusCircle, Trophy, HelpCircle, Flame, Coins } from 'lucide-react';
import { UserProfile } from '../types';

interface HeaderProps {
  user: UserProfile;
  activeTab: 'live' | 'dutch' | 'sealed' | 'vault';
  setActiveTab: (tab: 'live' | 'dutch' | 'sealed' | 'vault') => void;
  onOpenMint: () => void;
  onOpenRules: () => void;
  onOpenVault: () => void;
  onFaucetReload: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  onlineCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  user,
  activeTab,
  setActiveTab,
  onOpenMint,
  onOpenRules,
  onOpenVault,
  onFaucetReload,
  isMuted,
  onToggleMute,
  onlineCount,
}) => {
  return (
    <header className="sticky top-0 z-50 bg-[#08090c]/90 backdrop-blur-md border-b border-zinc-800/80 px-4 lg:px-8 py-3.5 transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <a
            href="/"
            onClick={(e) => {
              e.preventDefault();
              setActiveTab('live');
            }}
            className="text-xl lg:text-2xl font-black tracking-tighter uppercase font-display text-white hover:text-amber-400 transition-colors flex items-center gap-2"
          >
            <span>Auction Anarchy</span>
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" title="Live Server Connected" />
          </a>
          <span className="hidden sm:inline-block text-xs font-mono text-zinc-500 tabular-nums">
            {onlineCount} in arena
          </span>
        </div>

        {/* Zone 2: Clean text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-zinc-400">
          <button
            onClick={() => setActiveTab('live')}
            className={`transition-colors hover:text-white pb-0.5 ${
              activeTab === 'live' ? 'text-amber-400 font-semibold border-b-2 border-amber-400' : ''
            }`}
          >
            Live Floor
          </button>
          <button
            onClick={() => setActiveTab('dutch')}
            className={`transition-colors hover:text-white pb-0.5 ${
              activeTab === 'dutch' ? 'text-amber-400 font-semibold border-b-2 border-amber-400' : ''
            }`}
          >
            Dutch Decay
          </button>
          <button
            onClick={() => setActiveTab('sealed')}
            className={`transition-colors hover:text-white pb-0.5 ${
              activeTab === 'sealed' ? 'text-amber-400 font-semibold border-b-2 border-amber-400' : ''
            }`}
          >
            Sealed Duels
          </button>
          <button
            onClick={onOpenVault}
            className={`transition-colors hover:text-white pb-0.5 flex items-center gap-1.5 ${
              activeTab === 'vault' ? 'text-amber-400 font-semibold border-b-2 border-amber-400' : ''
            }`}
          >
            <span>Trophy Vault</span>
            {user.wonLots.length > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-400 text-xs font-mono font-bold">
                {user.wonLots.length}
              </span>
            )}
          </button>
          <button
            onClick={onOpenRules}
            className="transition-colors hover:text-white flex items-center gap-1 text-zinc-400"
          >
            <span>Snipe Rules</span>
          </button>
        </nav>

        {/* Zone 3: Primary actions & User Wallet */}
        <div className="flex items-center gap-2.5 sm:gap-3 shrink-0">
          {/* Sound Toggle */}
          <button
            onClick={onToggleMute}
            title={isMuted ? 'Unmute Sound' : 'Mute Sound'}
            className="p-2 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white hover:border-zinc-700 transition-colors"
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-zinc-500" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>

          {/* Wallet Balance Display with quick top-up */}
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-900/90 border border-zinc-800 text-xs font-mono">
            <Coins className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-zinc-400 hidden sm:inline">Bal:</span>
            <span className="font-bold text-amber-300 tabular-nums">
              ${user.balance.toLocaleString()}
            </span>
            <button
              onClick={onFaucetReload}
              title="Claim +$10,000 Reload"
              className="ml-1 text-[11px] font-sans text-amber-400/80 hover:text-amber-300 underline underline-offset-2"
            >
              +Reload
            </button>
          </div>

          {/* Mint New Auction Button */}
          <button
            onClick={onOpenMint}
            className="px-3.5 py-2 text-xs font-semibold text-black bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 rounded-lg shadow-sm hover:shadow-amber-500/20 transition-all flex items-center gap-1.5 whitespace-nowrap active:scale-95"
          >
            <PlusCircle className="w-3.5 h-3.5 text-black" />
            <span className="hidden sm:inline">Mint &amp; Drop</span>
            <span className="sm:hidden">Drop</span>
          </button>
        </div>
      </div>
    </header>
  );
};
