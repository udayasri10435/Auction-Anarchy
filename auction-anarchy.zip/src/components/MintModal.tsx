import React, { useState } from 'react';
import { AuctionType, Collectible, CollectibleRarity, VisualTheme, UserProfile } from '../types';
import { CollectibleVisualizer } from './CollectibleVisualizer';
import { X, Sparkles, Zap, Flame, Check } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  onMintAuction: (data: {
    collectible: Omit<Collectible, 'id' | 'tokenHash'>;
    type: AuctionType;
    startingPrice: number;
    durationSeconds: number;
  }) => void;
}

export const MintModal: React.FC<Props> = ({ isOpen, onClose, user, onMintAuction }) => {
  const [title, setTitle] = useState('CYBER ARCHON #07');
  const [series, setSeries] = useState('Anarchy Protocol');
  const [description, setDescription] = useState('Hyper-dimensional autonomous agent minted for live bidding combat.');
  const [theme, setTheme] = useState<VisualTheme>('cyber-samurai');
  const [rarity, setRarity] = useState<CollectibleRarity>('LEGENDARY');
  const [auctionType, setAuctionType] = useState<AuctionType>('BLITZ');
  const [startingPrice, setStartingPrice] = useState(1200);
  const [durationSeconds, setDurationSeconds] = useState(60);
  const [seed, setSeed] = useState(1337);

  if (!isOpen) return null;

  const previewCollectible: Collectible = {
    id: 'preview',
    title: title || 'Untitled Artifact',
    series: series || 'Custom Genesis',
    edition: '01/01',
    description,
    rarity,
    visualTheme: theme,
    visualSeed: seed,
    traits: [
      { label: 'Anarchy Vector', value: 'Prime', rarityPercent: 3 },
      { label: 'Harmonic Sync', value: '432 Hz', rarityPercent: 12 },
      { label: 'Origin', value: 'Live Mint Forge', rarityPercent: 1 },
    ],
    creatorName: user.name,
    creatorAvatar: user.avatar,
    tokenHash: '0xPENDING_MINT...',
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onMintAuction({
      collectible: {
        title: title || 'Untitled Artifact',
        series: series || 'Custom Series',
        edition: '01/01',
        description,
        rarity,
        visualTheme: theme,
        visualSeed: seed,
        traits: [
          { label: 'Anarchy Vector', value: 'Prime', rarityPercent: 3 },
          { label: 'Harmonic Sync', value: `${Math.floor(Math.random() * 800 + 100)} Hz`, rarityPercent: 12 },
          { label: 'Origin', value: 'Live Mint Forge', rarityPercent: 1 },
        ],
        creatorName: user.name,
        creatorAvatar: user.avatar,
      },
      type: auctionType,
      startingPrice: Number(startingPrice),
      durationSeconds: Number(durationSeconds),
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-3xl rounded-2xl bg-zinc-950 border border-zinc-800 shadow-2xl p-6 lg:p-8 my-8 text-zinc-100">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-6">
          <Sparkles className="w-5 h-5 text-amber-400" />
          <h2 className="text-xl font-bold font-display uppercase tracking-tight text-white">
            Mint &amp; Drop Collectible
          </h2>
        </div>

        <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-12 gap-8">
          {/* Left Column: Live Visualizer Preview */}
          <div className="md:col-span-5 flex flex-col items-center justify-center">
            <div className="w-full flex justify-center">
              <CollectibleVisualizer
                collectible={previewCollectible}
                size="md"
                interactive={true}
              />
            </div>

            <button
              type="button"
              onClick={() => setSeed(Math.floor(Math.random() * 9999))}
              className="mt-3 text-xs font-mono text-amber-400 hover:text-amber-300 underline underline-offset-4"
            >
              🎲 Reroll Visual Seed (#{seed})
            </button>
          </div>

          {/* Right Column: Configuration */}
          <div className="md:col-span-7 space-y-4 text-xs font-mono">
            <div>
              <label className="block text-zinc-400 uppercase tracking-wider mb-1">
                Artifact Name
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-100 text-sm focus:outline-none focus:border-amber-400"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-zinc-400 uppercase tracking-wider mb-1">
                  Collection Series
                </label>
                <input
                  type="text"
                  required
                  value={series}
                  onChange={(e) => setSeries(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-100 text-sm focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-zinc-400 uppercase tracking-wider mb-1">
                  Rarity Tier
                </label>
                <select
                  value={rarity}
                  onChange={(e) => setRarity(e.target.value as CollectibleRarity)}
                  className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-100 text-sm focus:outline-none focus:border-amber-400"
                >
                  <option value="RARE">Rare (Emerald)</option>
                  <option value="LEGENDARY">Legendary (Cyan)</option>
                  <option value="MYTHIC">Mythic (Gold)</option>
                  <option value="CHAOS">Chaos (Fuchsia)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-zinc-400 uppercase tracking-wider mb-1">
                Visual Art Aesthetic
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'cyber-samurai', label: 'Cyber Samurai' },
                  { id: 'sol-deity', label: 'Sol Deity' },
                  { id: 'neon-drifter', label: 'Neon Drifter' },
                  { id: 'void-monolith', label: 'Void Monolith' },
                  { id: 'pixel-punk', label: 'Pixel Punk' },
                ].map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => setTheme(t.id as VisualTheme)}
                    className={`p-2 rounded-lg border text-center transition-all text-[11px] ${
                      theme === t.id
                        ? 'bg-amber-400/20 border-amber-400 text-amber-300 font-bold'
                        : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-zinc-400 uppercase tracking-wider mb-1">
                  Auction Type
                </label>
                <select
                  value={auctionType}
                  onChange={(e) => setAuctionType(e.target.value as AuctionType)}
                  className="w-full px-2.5 py-2 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-100 text-xs focus:outline-none focus:border-amber-400"
                >
                  <option value="BLITZ">Blitz (Timed)</option>
                  <option value="DUTCH">Dutch Decay</option>
                  <option value="SEALED_DUEL">Sealed Duel</option>
                </select>
              </div>

              <div>
                <label className="block text-zinc-400 uppercase tracking-wider mb-1">
                  Start Price ($)
                </label>
                <input
                  type="number"
                  min="100"
                  step="100"
                  value={startingPrice}
                  onChange={(e) => setStartingPrice(Number(e.target.value))}
                  className="w-full px-2.5 py-2 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-100 text-xs focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-zinc-400 uppercase tracking-wider mb-1">
                  Duration (Secs)
                </label>
                <select
                  value={durationSeconds}
                  onChange={(e) => setDurationSeconds(Number(e.target.value))}
                  className="w-full px-2.5 py-2 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-100 text-xs focus:outline-none focus:border-amber-400"
                >
                  <option value={30}>30s (Hyper Blitz)</option>
                  <option value={60}>60s (Standard)</option>
                  <option value={90}>90s (Long War)</option>
                </select>
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-black font-extrabold uppercase font-mono tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 active:scale-98 transition-all"
              >
                <Zap className="w-4 h-4 fill-black" />
                <span>MINT &amp; DROP ON LIVE FLOOR</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
