import React, { useState } from 'react';
import { Collectible, UserProfile } from '../types';
import { CollectibleVisualizer } from './CollectibleVisualizer';
import { Trophy, X, Shield, ExternalLink, Sparkles } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
}

export const TrophyVaultModal: React.FC<Props> = ({ isOpen, onClose, user }) => {
  const [selectedPiece, setSelectedPiece] = useState<Collectible | null>(
    user.wonLots[0] || null
  );

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-4xl rounded-2xl bg-zinc-950 border border-zinc-800 shadow-2xl p-6 lg:p-8 my-8 text-zinc-100">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-6">
          <Trophy className="w-6 h-6 text-amber-400" />
          <div>
            <h2 className="text-xl font-bold font-display uppercase tracking-tight text-white">
              Trophy Vault &amp; Armory
            </h2>
            <p className="text-xs text-zinc-400 font-mono">
              Collector: {user.name} ({user.handle}) · {user.wonLots.length} Artifacts Claimed
            </p>
          </div>
        </div>

        {user.wonLots.length === 0 ? (
          <div className="text-center py-16 px-4 rounded-xl border border-dashed border-zinc-800">
            <Trophy className="w-12 h-12 text-zinc-600 mx-auto mb-3" />
            <h3 className="text-lg font-bold text-zinc-300 font-display">Your Vault is Empty</h3>
            <p className="text-xs text-zinc-500 font-mono max-w-md mx-auto mt-1">
              Enter the live bidding floor or snipe a ticking Dutch auction to claim digital artifacts and immortalize your handle on the ledger!
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
            {/* Won Items Grid */}
            <div className="md:col-span-5 space-y-3 max-h-[460px] overflow-y-auto pr-2">
              {user.wonLots.map((item) => (
                <div
                  key={item.id}
                  onClick={() => setSelectedPiece(item)}
                  className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center gap-3 ${
                    selectedPiece?.id === item.id
                      ? 'bg-amber-500/10 border-amber-400/60 shadow-md'
                      : 'bg-zinc-900/50 border-zinc-800 hover:border-zinc-700'
                  }`}
                >
                  <div className="w-14 h-14 shrink-0 rounded-lg overflow-hidden border border-zinc-700">
                    <CollectibleVisualizer collectible={item} size="sm" interactive={false} />
                  </div>
                  <div className="overflow-hidden">
                    <div className="text-[10px] font-mono text-zinc-400 truncate">{item.series}</div>
                    <div className="text-sm font-bold text-white truncate font-display">{item.title}</div>
                    <div className="text-[11px] font-mono text-amber-400 font-semibold">{item.rarity}</div>
                  </div>
                </div>
              ))}
            </div>

            {/* Inspection Panel */}
            <div className="md:col-span-7 p-5 rounded-xl bg-zinc-900/60 border border-zinc-800 flex flex-col justify-between">
              {selectedPiece ? (
                <>
                  <div className="flex flex-col items-center">
                    <CollectibleVisualizer
                      collectible={selectedPiece}
                      size="hero"
                      interactive={true}
                    />

                    <div className="w-full mt-4 text-center">
                      <div className="text-xs font-mono text-zinc-400 uppercase tracking-wider">
                        {selectedPiece.series} · Edition {selectedPiece.edition}
                      </div>
                      <h3 className="text-xl font-extrabold text-white font-display mt-0.5">
                        {selectedPiece.title}
                      </h3>
                      <p className="text-xs text-zinc-400 mt-1 max-w-sm mx-auto">
                        {selectedPiece.description}
                      </p>
                    </div>
                  </div>

                  <div className="mt-5 pt-4 border-t border-zinc-800">
                    <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                      <div className="p-2 rounded bg-zinc-950/80 border border-zinc-800">
                        <div className="text-[10px] text-zinc-500 uppercase">Creator</div>
                        <div className="text-zinc-200 font-semibold truncate">{selectedPiece.creatorName}</div>
                      </div>
                      <div className="p-2 rounded bg-zinc-950/80 border border-zinc-800">
                        <div className="text-[10px] text-zinc-500 uppercase">Provenance Hash</div>
                        <div className="text-zinc-200 font-semibold truncate">{selectedPiece.tokenHash}</div>
                      </div>
                    </div>
                  </div>
                </>
              ) : (
                <div className="text-center py-12 text-zinc-500 font-mono text-xs">
                  Select a trophy from the list to inspect cryptographic metadata
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
