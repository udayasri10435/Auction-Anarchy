import React, { useState, useEffect } from 'react';
import { AuctionLot, UserProfile } from '../types';
import { CollectibleVisualizer } from './CollectibleVisualizer';
import { sound } from '../utils/audio';
import { Zap, TrendingDown, Lock, Clock, ArrowUpRight, CheckCircle2, ShieldAlert } from 'lucide-react';

interface Props {
  lot: AuctionLot;
  user: UserProfile;
  onSelect: (lot: AuctionLot) => void;
  onClaimDutch: (lotId: string) => void;
  onSubmitSealed: (lotId: string, amount: number) => void;
  serverTimeOffset: number;
}

export const AuctionCard: React.FC<Props> = ({
  lot,
  user,
  onSelect,
  onClaimDutch,
  onSubmitSealed,
  serverTimeOffset,
}) => {
  const [timeLeftSec, setTimeLeftSec] = useState<number>(0);
  const [sealedBidAmount, setSealedBidAmount] = useState<string>('');
  const [showSealedModal, setShowSealedModal] = useState<boolean>(false);

  useEffect(() => {
    const updateTime = () => {
      const now = Date.now() + serverTimeOffset;
      const remaining = Math.max(0, Math.floor((lot.endsAt - now) / 1000));
      setTimeLeftSec(remaining);
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, [lot.endsAt, serverTimeOffset]);

  const isSold = lot.status === 'SOLD' || lot.status === 'ENDED' || timeLeftSec <= 0;
  const isEndingSoon = timeLeftSec <= 10 && timeLeftSec > 0 && !isSold;
  const isUserHighBidder = lot.highestBidderId === user.id;

  const handleDutchClaim = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (lot.currentPrice > user.balance) {
      alert(`Insufficient balance! Your balance is $${user.balance.toLocaleString()}`);
      return;
    }
    sound.playBid();
    onClaimDutch(lot.id);
  };

  const handleSealedSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const val = parseInt(sealedBidAmount, 10);
    if (isNaN(val) || val <= 0) return;
    if (val > user.balance) {
      alert('Sealed bid cannot exceed current wallet balance.');
      return;
    }
    sound.playBid();
    onSubmitSealed(lot.id, val);
    setShowSealedModal(false);
    setSealedBidAmount('');
  };

  return (
    <div
      onClick={() => onSelect(lot)}
      className={`group relative rounded-xl border bg-zinc-950/70 backdrop-blur-md p-4 transition-all duration-200 cursor-pointer flex flex-col justify-between hover:border-zinc-700 hover:shadow-xl ${
        isEndingSoon
          ? 'border-red-500/50 shadow-[0_0_20px_rgba(239,68,68,0.2)]'
          : isUserHighBidder
          ? 'border-emerald-500/50'
          : 'border-zinc-800'
      }`}
    >
      <div>
        {/* Top Header Badge */}
        <div className="flex items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-1.5 text-xs font-mono">
            {lot.type === 'BLITZ' && (
              <span className="flex items-center gap-1 px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 font-semibold border border-amber-500/20 text-[11px]">
                <Zap className="w-3 h-3" /> BLITZ
              </span>
            )}
            {lot.type === 'DUTCH' && (
              <span className="flex items-center gap-1 px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-400 font-semibold border border-cyan-500/20 text-[11px]">
                <TrendingDown className="w-3 h-3" /> DUTCH DECAY
              </span>
            )}
            {lot.type === 'SEALED_DUEL' && (
              <span className="flex items-center gap-1 px-2 py-0.5 rounded bg-purple-500/10 text-purple-400 font-semibold border border-purple-500/20 text-[11px]">
                <Lock className="w-3 h-3" /> SEALED DUEL
              </span>
            )}
          </div>

          {/* Time indicator */}
          <div className={`flex items-center gap-1 font-mono text-xs tabular-nums ${
            isEndingSoon ? 'text-red-400 font-bold animate-pulse' : 'text-zinc-400'
          }`}>
            <Clock className="w-3.5 h-3.5" />
            <span>
              {isSold ? 'ENDED' : `${Math.floor(timeLeftSec / 60)}:${String(timeLeftSec % 60).padStart(2, '0')}`}
            </span>
          </div>
        </div>

        {/* Visualizer Frame */}
        <div className="w-full flex justify-center py-2">
          <CollectibleVisualizer
            collectible={lot.collectible}
            size="md"
            interactive={false}
            isHighBid={isUserHighBidder}
          />
        </div>

        {/* Info */}
        <div className="mt-3">
          <div className="text-[11px] font-mono text-zinc-500 truncate">{lot.collectible.series}</div>
          <h3 className="text-base font-bold text-white group-hover:text-amber-400 transition-colors truncate font-display">
            {lot.collectible.title}
          </h3>
        </div>
      </div>

      {/* Bottom Action Area */}
      <div className="mt-4 pt-3 border-t border-zinc-800/80">
        <div className="flex items-end justify-between mb-3">
          <div>
            <div className="text-[10px] font-mono uppercase text-zinc-500">
              {lot.type === 'DUTCH' ? 'Current Ticking Price' : lot.type === 'SEALED_DUEL' ? 'Reserve Anchor' : 'High Bid'}
            </div>
            <div className="text-xl font-extrabold text-white font-mono tabular-nums">
              ${lot.currentPrice.toLocaleString()}
            </div>
          </div>

          {lot.type === 'SEALED_DUEL' && (
            <div className="text-right text-[11px] font-mono text-purple-400">
              {lot.blindBidsCount || 0} sealed bids
            </div>
          )}

          {lot.type === 'BLITZ' && lot.highestBidderName && (
            <div className="text-right text-[11px] font-mono text-zinc-400 truncate max-w-[120px]">
              by <strong className="text-zinc-200">{lot.highestBidderId === user.id ? 'You' : lot.highestBidderName}</strong>
            </div>
          )}
        </div>

        {/* Dynamic Button based on Auction Type */}
        {lot.type === 'DUTCH' && !isSold ? (
          <button
            onClick={handleDutchClaim}
            className="w-full py-2 px-3 rounded-lg bg-cyan-500 hover:bg-cyan-400 active:scale-95 text-black font-mono font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all shadow-md shadow-cyan-500/20"
          >
            <span>CLAIM FOR ${lot.currentPrice.toLocaleString()}</span>
            <CheckCircle2 className="w-3.5 h-3.5" />
          </button>
        ) : lot.type === 'SEALED_DUEL' && !isSold ? (
          <div>
            {showSealedModal ? (
              <form onSubmit={handleSealedSubmit} className="flex gap-1.5" onClick={(e) => e.stopPropagation()}>
                <input
                  type="number"
                  min={lot.currentPrice}
                  value={sealedBidAmount}
                  onChange={(e) => setSealedBidAmount(e.target.value)}
                  placeholder="Secret $"
                  className="w-full px-2 py-1.5 rounded bg-zinc-900 border border-zinc-700 text-xs font-mono text-white focus:outline-none focus:border-purple-400"
                />
                <button
                  type="submit"
                  className="px-2.5 py-1.5 rounded bg-purple-500 hover:bg-purple-400 text-white font-mono text-xs font-bold whitespace-nowrap"
                >
                  Seal
                </button>
              </form>
            ) : (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setShowSealedModal(true);
                }}
                className="w-full py-2 px-3 rounded-lg bg-purple-600/30 hover:bg-purple-600/50 border border-purple-500/40 text-purple-200 font-mono font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>ENTER BLIND BID</span>
              </button>
            )}
          </div>
        ) : (
          <button
            onClick={() => onSelect(lot)}
            className="w-full py-2 px-3 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-300 font-mono font-medium text-xs flex items-center justify-center gap-1.5 transition-all"
          >
            <span>{isSold ? 'View Results' : 'Join Live War'}</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    </div>
  );
};
