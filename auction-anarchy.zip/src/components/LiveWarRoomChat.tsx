import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage, UserProfile } from '../types';
import { Send, Flame, Skull, Rocket, DollarSign, Hammer, Zap, MessageSquare } from 'lucide-react';

interface Props {
  messages: ChatMessage[];
  user: UserProfile;
  onSendMessage: (text?: string, reaction?: string) => void;
  onlineCount: number;
}

export const LiveWarRoomChat: React.FC<Props> = ({
  messages,
  user,
  onSendMessage,
  onlineCount,
}) => {
  const [inputText, setInputText] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [floatingReactions, setFloatingReactions] = useState<{ id: string; emoji: string; left: number }[]>([]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendText = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    onSendMessage(inputText.trim(), undefined);
    setInputText('');
  };

  const handleSendReaction = (emoji: string) => {
    onSendMessage(undefined, emoji);
    triggerFloatingReaction(emoji);
  };

  const triggerFloatingReaction = (emoji: string) => {
    const id = `float-${Date.now()}-${Math.random()}`;
    const left = Math.random() * 80 + 10;
    setFloatingReactions((prev) => [...prev, { id, emoji, left }]);
    setTimeout(() => {
      setFloatingReactions((prev) => prev.filter((r) => r.id !== id));
    }, 1800);
  };

  return (
    <div className="relative flex flex-col h-[480px] lg:h-full rounded-2xl border border-zinc-800 bg-zinc-950/80 backdrop-blur-md overflow-hidden">
      {/* Floating Reaction Particles */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-20">
        {floatingReactions.map((r) => (
          <span
            key={r.id}
            className="absolute bottom-16 text-2xl transition-all duration-1000 ease-out animate-bounce pointer-events-none"
            style={{
              left: `${r.left}%`,
              animation: 'floatUp 1.8s forwards',
            }}
          >
            {r.emoji}
          </span>
        ))}
      </div>

      <style>{`
        @keyframes floatUp {
          0% { transform: translateY(0) scale(0.8); opacity: 1; }
          100% { transform: translateY(-300px) scale(1.6); opacity: 0; }
        }
      `}</style>

      {/* Header */}
      <div className="p-3.5 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/50">
        <div className="flex items-center gap-2">
          <MessageSquare className="w-4 h-4 text-amber-400" />
          <span className="text-xs font-mono font-bold uppercase tracking-wider text-zinc-200">
            WAR ROOM BANTER
          </span>
        </div>
        <div className="flex items-center gap-1.5 text-[11px] font-mono text-zinc-400">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>{onlineCount} Online</span>
        </div>
      </div>

      {/* Message Feed */}
      <div className="flex-1 overflow-y-auto p-3.5 space-y-2.5 text-xs font-mono">
        {messages.map((m) => {
          if (m.isSystemAnnouncement) {
            return (
              <div
                key={m.id}
                className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-200 text-[11px] leading-relaxed"
              >
                {m.text}
              </div>
            );
          }

          if (m.reaction) {
            return (
              <div key={m.id} className="flex items-center gap-1.5 text-zinc-400 text-[11px]">
                <img
                  src={m.userAvatar}
                  alt=""
                  className="w-4 h-4 rounded-full bg-zinc-800"
                  referrerPolicy="no-referrer"
                />
                <span className="text-zinc-300 font-semibold">{m.userName}</span>
                <span>reacted with</span>
                <span className="text-base">{m.reaction}</span>
              </div>
            );
          }

          const isSelf = m.userId === user.id;

          return (
            <div
              key={m.id}
              className={`flex items-start gap-2 ${isSelf ? 'justify-end' : 'justify-start'}`}
            >
              {!isSelf && (
                <img
                  src={m.userAvatar}
                  alt=""
                  className="w-5 h-5 rounded-full bg-zinc-800 shrink-0 mt-0.5"
                  referrerPolicy="no-referrer"
                />
              )}
              <div
                className={`max-w-[85%] rounded-lg p-2.5 text-xs ${
                  isSelf
                    ? 'bg-amber-400 text-black font-semibold'
                    : 'bg-zinc-900 border border-zinc-800 text-zinc-200'
                }`}
              >
                {!isSelf && (
                  <div className="text-[10px] text-zinc-400 font-bold mb-0.5">{m.userName}</div>
                )}
                <div className="break-words leading-tight">{m.text}</div>
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Reaction Bar */}
      <div className="px-3 py-1.5 border-t border-zinc-800/80 bg-zinc-900/30 flex items-center justify-around">
        {[
          { icon: '🔥', label: 'fire' },
          { icon: '💀', label: 'skull' },
          { icon: '🚀', label: 'rocket' },
          { icon: '💸', label: 'money' },
          { icon: '🔨', label: 'hammer' },
          { icon: '⚡', label: 'bolt' },
        ].map((item) => (
          <button
            key={item.label}
            onClick={() => handleSendReaction(item.icon)}
            className="p-1 text-base hover:scale-125 active:scale-95 transition-transform"
            title={`React with ${item.icon}`}
          >
            {item.icon}
          </button>
        ))}
      </div>

      {/* Input Box */}
      <form onSubmit={handleSendText} className="p-2.5 border-t border-zinc-800 flex gap-1.5 bg-zinc-950">
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Hype, taunt, or call out snipers..."
          className="flex-1 px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-800 text-xs font-mono text-zinc-200 placeholder:text-zinc-600 focus:outline-none focus:border-amber-400"
        />
        <button
          type="submit"
          className="p-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 transition-colors"
          title="Send Message"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};
