import React, { useState, useEffect } from 'react';
import { AuctionLot, UserProfile } from '../types';
import { CollectibleVisualizer } from './CollectibleVisualizer';
import { sound } from '../utils/audio';
import { ShieldAlert, Zap, Clock, User, ArrowUpRight, Flame, AlertCircle, Award } from 'lucide-react';

interface Props {
  lot: AuctionLot;
  user: UserProfile;
  onPlaceBid: (lotId: string, amount: number) => void;
  serverTimeOffset: number;
}

export const LiveAuctionStage: React.FC<Props> = ({
  lot,
  user,
  onPlaceBid,
  serverTimeOffset,
}) => {
  const [timeLeftMs, setTimeLeftMs] = useState<number>(0);
  const [customBid, setCustomBid] = useState<string>('');
  const [bidError, setBidError] = useState<string | null>(null);
  const [justBid, setJustBid] = useState<boolean>(false);

  // Sync countdown timer every 100ms for smooth sub-second ticking
  useEffect(() => {
    const interval = setInterval(() => {
      const now = Date.now() + serverTimeOffset;
      const remaining = Math.max(0, lot.endsAt - now);
      setTimeLeftMs(remaining);

      // Play subtle heartbeat in the last 7 seconds
      if (remaining > 0 && remaining <= 7000 && Math.floor(remaining / 1000) !== Math.floor((remaining + 100) / 1000)) {
        sound.playHeartbeat();
      }
    }, 100);

    return () => clearInterval(interval);
  }, [lot.endsAt, serverTimeOffset]);

  const remainingSeconds = Math.max(0, Math.floor(timeLeftMs / 1000));
  const remainingMillis = Math.max(0, Math.floor((timeLeftMs % 1000) / 100));
  const isEndingSoon = remainingSeconds <= 10 && remainingSeconds > 0 && lot.status !== 'SOLD';
  const isSold = lot.status === 'SOLD' || lot.status === 'ENDED' || timeLeftMs <= 0;

  const isUserHighBidder = lot.highestBidderId === user.id;
  const userWasOutbid = !isUserHighBidder && lot.bids.some((b) => b.bidderId === user.id);

  const minNextBid = lot.currentPrice + (lot.bids.length === 0 ? 0 : lot.minIncrement);

  const handleQuickBid = (increment: number) => {
    setBidError(null);
    const amount = lot.currentPrice + increment;
    if (amount > user.balance) {
      setBidError(`Insufficient balance ($${user.balance.toLocaleString()}). Tap +Reload!`);
      return;
    }
    sound.playBid();
    setJustBid(true);
    setTimeout(() => setJustBid(false), 500);
    onPlaceBid(lot.id, amount);
  };

  const handleCustomBidSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setBidError(null);
    const val = parseInt(customBid, 10);
    if (isNaN(val) || val < minNextBid) {
      setBidError(`Minimum bid is $${minNextBid.toLocaleString()}`);
      return;
    }
    if (val > user.balance) {
      setBidError(`Insufficient balance ($${user.balance.toLocaleString()}). Tap +Reload!`);
      return;
    }
    sound.playBid();
    setJustBid(true);
    setTimeout(() => setJustBid(false), 500);
    onPlaceBid(lot.id, val);
    setCustomBid('');
  };

  return (
    <div className={`relative rounded-2xl border transition-all duration-300 p-4 lg:p-7 bg-zinc-950/70 backdrop-blur-xl ${
      isEndingSoon
        ? 'border-red-500/70 shadow-[0_0_40px_rgba(239,68,68,0.25)]'
        : isUserHighBidder
        ? 'border-emerald-500/50 shadow-[0_0_35px_rgba(16,185,129,0.15)]'
        : 'border-zinc-800 shadow-2xl'
    }`}>
      {/* Top Banner Status Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6 pb-4 border-b border-zinc-800/80">
        <div className="flex items-center gap-2.5">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-mono font-semibold">
            <Zap className="w-3.5 h-3.5 fill-amber-400" />
            <span>{lot.type} AUCTION</span>
          </div>

          <span className="text-zinc-500 text-xs font-mono">
            {lot.collectible.series} · Edition {lot.collectible.edition}
          </span>
        </div>

        {/* Live Countdown & Anti-Snipe Status */}
        <div className="flex items-center gap-3">
          {lot.snipeExtensionsCount > 0 && (
            <div className="flex items-center gap-1 px-2.5 py-1 rounded bg-red-950/50 border border-red-500/30 text-[11px] font-mono text-red-400 font-bold animate-pulse">
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>+{lot.snipeExtensionsCount * 15}s SNIPE EXTENSION</span>
            </div>
          )}

          <div className={`flex items-center gap-2 px-3 py-1 rounded-lg border font-mono ${
            isEndingSoon
              ? 'bg-red-500/20 border-red-500 text-red-400 animate-pulse'
              : isSold
              ? 'bg-zinc-800 border-zinc-700 text-zinc-400'
              : 'bg-zinc-900 border-zinc-700 text-zinc-200'
          }`}>
            <Clock className="w-4 h-4 text-zinc-400" />
            <span className="text-xs uppercase text-zinc-400">
              {isSold ? 'Hammer Down' : 'Time Left'}:
            </span>
            <span className="text-base font-extrabold tracking-wider tabular-nums">
              {isSold ? 'SOLD' : `${String(Math.floor(remainingSeconds / 60)).padStart(2, '0')}:${String(remainingSeconds % 60).padStart(2, '0')}.${remainingMillis}`}
            </span>
          </div>
        </div>
      </div>

      {/* Main Split Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Visualizer & Collectible Metadata */}
        <div className="lg:col-span-6 flex flex-col items-center">
          <div className="w-full flex justify-center">
            <CollectibleVisualizer
              collectible={lot.collectible}
              size="hero"
              interactive={true}
              isHighBid={isUserHighBidder}
            />
          </div>

          {/* Traits and Provenance Grid */}
          <div className="w-full max-w-[420px] mt-4 p-3.5 rounded-xl bg-zinc-900/60 border border-zinc-800/80">
            <div className="flex items-center justify-between text-xs text-zinc-400 mb-2.5">
              <span className="font-mono uppercase text-[11px] text-zinc-500">Cryptographic Traits</span>
              <span className="font-mono text-zinc-500">{lot.collectible.tokenHash}</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {lot.collectible.traits.map((trait, idx) => (
                <div key={idx} className="p-2 rounded bg-zinc-950/60 border border-zinc-800">
                  <div className="text-[10px] text-zinc-500 uppercase font-mono">{trait.label}</div>
                  <div className="font-semibold text-zinc-200 font-mono mt-0.5 truncate">{trait.value}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Bid War Control Center */}
        <div className="lg:col-span-6 flex flex-col justify-between h-full">
          <div>
            <div className="flex items-start justify-between gap-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight font-display">
                  {lot.collectible.title}
                </h1>
                <p className="text-zinc-400 text-xs sm:text-sm mt-1 line-clamp-2">
                  {lot.collectible.description}
                </p>
              </div>
            </div>

            {/* Anti-Snipe Warning Alert */}
            {isEndingSoon && (
              <div className="mt-4 p-3 rounded-xl bg-red-950/70 border border-red-500/80 text-red-200 text-xs flex items-center gap-2.5 shadow-lg shadow-red-950/50">
                <ShieldAlert className="w-5 h-5 text-red-400 shrink-0 animate-bounce" />
                <div>
                  <span className="font-bold text-red-300">ANTI-SNIPE SHIELD ACTIVE!</span> Any bid placed under 10 seconds adds <strong>+15s</strong> to the clock to prevent bot sniping!
                </div>
              </div>
            )}

            {/* Price & Bidder Indicator */}
            <div className="mt-5 p-5 rounded-xl bg-zinc-900/90 border border-zinc-800">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs uppercase font-mono tracking-wider text-zinc-400">
                    Current Highest Bid
                  </div>
                  <div className="text-3xl sm:text-4xl font-extrabold text-white font-mono tabular-nums tracking-tight mt-1 flex items-baseline gap-1">
                    <span className="text-amber-400">$</span>
                    <span>{lot.currentPrice.toLocaleString()}</span>
                  </div>
                </div>

                {/* Leading Bidder */}
                <div className="text-right">
                  <div className="text-xs uppercase font-mono text-zinc-500">Leading Bidder</div>
                  <div className="flex items-center justify-end gap-2 mt-1">
                    {lot.highestBidderAvatar ? (
                      <img
                        src={lot.highestBidderAvatar}
                        alt="Bidder"
                        className="w-6 h-6 rounded-full border border-zinc-700 bg-zinc-800"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-6 h-6 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center text-zinc-400">
                        <User className="w-3.5 h-3.5" />
                      </div>
                    )}
                    <span className="font-mono text-sm font-bold text-zinc-200">
                      {lot.highestBidderName || 'No Bids Yet'}
                    </span>
                  </div>
                </div>
              </div>

              {/* User Standing Status Pill */}
              <div className="mt-3 pt-3 border-t border-zinc-800/80 flex items-center justify-between text-xs">
                {isUserHighBidder ? (
                  <div className="flex items-center gap-1.5 text-emerald-400 font-bold font-mono">
                    <Flame className="w-4 h-4 text-emerald-400 animate-pulse" />
                    <span>YOU ARE THE HIGHEST BIDDER! HOLD THE LINE!</span>
                  </div>
                ) : userWasOutbid ? (
                  <div className="flex items-center gap-1.5 text-red-400 font-bold font-mono">
                    <AlertCircle className="w-4 h-4 text-red-400" />
                    <span>YOU WERE OUTBID! RETALIATE NOW!</span>
                  </div>
                ) : (
                  <div className="text-zinc-500 font-mono">
                    Next minimum valid bid: <strong className="text-zinc-300 font-bold">${minNextBid.toLocaleString()}</strong>
                  </div>
                )}
              </div>
            </div>

            {/* Bid Actions (Disabled if Sold) */}
            {!isSold ? (
              <div className="mt-5 space-y-3">
                <div className="text-xs font-mono uppercase tracking-wider text-zinc-400">
                  Instant Blitz Counter-Bids
                </div>

                {/* Quick Add Buttons */}
                <div className="grid grid-cols-4 gap-2">
                  <button
                    onClick={() => handleQuickBid(lot.minIncrement)}
                    disabled={lot.currentPrice + lot.minIncrement > user.balance}
                    className="py-2.5 px-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 text-xs font-mono font-bold text-zinc-100 transition-all active:scale-95 disabled:opacity-40"
                  >
                    +${lot.minIncrement}
                  </button>
                  <button
                    onClick={() => handleQuickBid(250)}
                    disabled={lot.currentPrice + 250 > user.balance}
                    className="py-2.5 px-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 text-xs font-mono font-bold text-zinc-100 transition-all active:scale-95 disabled:opacity-40"
                  >
                    +$250
                  </button>
                  <button
                    onClick={() => handleQuickBid(500)}
                    disabled={lot.currentPrice + 500 > user.balance}
                    className="py-2.5 px-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 text-xs font-mono font-bold text-zinc-100 transition-all active:scale-95 disabled:opacity-40"
                  >
                    +$500
                  </button>
                  <button
                    onClick={() => handleQuickBid(Math.round(lot.currentPrice * 0.25))}
                    disabled={lot.currentPrice * 1.25 > user.balance}
                    className="py-2.5 px-2 rounded-lg bg-gradient-to-r from-amber-600/30 to-amber-500/20 hover:from-amber-600/40 hover:to-amber-500/30 border border-amber-500/40 text-xs font-mono font-bold text-amber-300 transition-all active:scale-95 disabled:opacity-40"
                    title="+25% Power Strike"
                  >
                    +25% Strike
                  </button>
                </div>

                {/* Custom Bid Submission Form */}
                <form onSubmit={handleCustomBidSubmit} className="flex gap-2">
                  <div className="relative flex-1">
                    <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-500 font-mono text-sm">$</span>
                    <input
                      type="number"
                      min={minNextBid}
                      step={lot.minIncrement}
                      value={customBid}
                      onChange={(e) => setCustomBid(e.target.value)}
                      placeholder={`Custom Snipe (min $${minNextBid.toLocaleString()})`}
                      className="w-full pl-8 pr-4 py-2.5 rounded-lg bg-zinc-900 border border-zinc-700 text-zinc-100 text-sm font-mono placeholder:text-zinc-600 focus:outline-none focus:border-amber-400 transition-colors"
                    />
                  </div>
                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-lg bg-amber-400 hover:bg-amber-300 active:scale-95 text-black font-bold font-mono text-xs uppercase tracking-wider flex items-center gap-1.5 transition-all shadow-md shadow-amber-500/20 whitespace-nowrap"
                  >
                    <span>SMASH BID</span>
                    <ArrowUpRight className="w-4 h-4" />
                  </button>
                </form>

                {bidError && (
                  <div className="text-xs text-red-400 font-mono flex items-center gap-1 mt-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>{bidError}</span>
                  </div>
                )}
              </div>
            ) : (
              <div className="mt-5 p-4 rounded-xl bg-zinc-900/60 border border-zinc-800 text-center">
                <Award className="w-8 h-8 text-amber-400 mx-auto mb-2" />
                <div className="text-lg font-bold text-white font-display">Auction Concluded</div>
                <div className="text-xs text-zinc-400 font-mono mt-1">
                  Won by <strong className="text-amber-300">{lot.highestBidderName || 'Reserve not met'}</strong> for <strong className="text-white">${lot.currentPrice.toLocaleString()}</strong>
                </div>
              </div>
            )}
          </div>

          {/* Bid History Stream */}
          <div className="mt-6 pt-4 border-t border-zinc-800/80">
            <div className="flex items-center justify-between text-xs text-zinc-400 mb-2 font-mono">
              <span>WAR LOG ({lot.bids.length} BIDS)</span>
              <span>LATEST COUNTERS</span>
            </div>

            <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
              {lot.bids.length === 0 ? (
                <div className="text-center py-4 text-xs text-zinc-600 font-mono">
                  No bids yet. Be the first to unleash chaos!
                </div>
              ) : (
                lot.bids.slice(0, 5).map((bid) => (
                  <div
                    key={bid.id}
                    className={`flex items-center justify-between px-3 py-1.5 rounded-lg border text-xs font-mono transition-all ${
                      bid.bidderId === user.id
                        ? 'bg-emerald-950/30 border-emerald-500/30 text-emerald-200'
                        : 'bg-zinc-900/50 border-zinc-800 text-zinc-300'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      <img
                        src={bid.bidderAvatar}
                        alt=""
                        className="w-4 h-4 rounded-full bg-zinc-800"
                        referrerPolicy="no-referrer"
                      />
                      <span className="font-semibold truncate">
                        {bid.bidderId === user.id ? 'You' : bid.bidderName}
                      </span>
                      {bid.isSnipe && (
                        <span className="px-1 py-0.2 rounded bg-red-950 text-red-400 text-[10px] font-bold border border-red-500/30">
                          SNIPE!
                        </span>
                      )}
                    </div>
                    <div className="font-bold text-amber-300 tabular-nums shrink-0">
                      ${bid.amount.toLocaleString()}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
