import React from 'react';
import { X, ShieldAlert, TrendingDown, Lock, Zap, Award } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const RulesModal: React.FC<Props> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-2xl rounded-2xl bg-zinc-950 border border-zinc-800 shadow-2xl p-6 lg:p-8 my-8 text-zinc-100">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-6">
          <Zap className="w-6 h-6 text-amber-400" />
          <h2 className="text-xl font-bold font-display uppercase tracking-tight text-white">
            Rules of the Anarchy Arena
          </h2>
        </div>

        <div className="space-y-4 text-xs font-mono">
          {/* Rule 1 */}
          <div className="p-4 rounded-xl bg-zinc-900/60 border border-zinc-800 flex gap-3.5">
            <ShieldAlert className="w-6 h-6 text-red-400 shrink-0 mt-0.5" />
            <div>
              <div className="text-sm font-bold text-red-300 font-display">
                01. Anti-Snipe Defense Shield (+15s Extension)
              </div>
              <p className="text-zinc-400 mt-1 leading-relaxed">
                Bots and last-second snipers cannot steal auctions in the dark. Whenever any bid is placed in the final <strong>10 seconds</strong> of an active lot, the authoritative server clock is instantly extended by <strong>+15 seconds</strong>, giving human bidders time to retaliate.
              </p>
            </div>
          </div>

          {/* Rule 2 */}
          <div className="p-4 rounded-xl bg-zinc-900/60 border border-zinc-800 flex gap-3.5">
            <TrendingDown className="w-6 h-6 text-cyan-400 shrink-0 mt-0.5" />
            <div>
              <div className="text-sm font-bold text-cyan-300 font-display">
                02. Dutch Decay Protocol (First-to-Click Snatch)
              </div>
              <p className="text-zinc-400 mt-1 leading-relaxed">
                In Dutch auctions, the price starts high and decays automatically every second. No counter-bids: the first collector brave enough to click "CLAIM" secures the artifact at the current ticker price!
              </p>
            </div>
          </div>

          {/* Rule 3 */}
          <div className="p-4 rounded-xl bg-zinc-900/60 border border-zinc-800 flex gap-3.5">
            <Lock className="w-6 h-6 text-purple-400 shrink-0 mt-0.5" />
            <div>
              <div className="text-sm font-bold text-purple-300 font-display">
                03. Sealed Blind Duels
              </div>
              <p className="text-zinc-400 mt-1 leading-relaxed">
                Submit confidential sealed bids. All bid amounts remain encrypted until the hammer drops at zero seconds. The highest secret bid claims the lot, keeping competitors on edge!
              </p>
            </div>
          </div>

          {/* Rule 4 */}
          <div className="p-4 rounded-xl bg-zinc-900/60 border border-zinc-800 flex gap-3.5">
            <Award className="w-6 h-6 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <div className="text-sm font-bold text-amber-300 font-display">
                04. Instant Trophy Settlement &amp; Faucet Reload
              </div>
              <p className="text-zinc-400 mt-1 leading-relaxed">
                Winning bids transfer artifacts directly into your Trophy Armory with verified token provenance hashes. If you run low on war funds, tap the <strong>+Reload</strong> button in the header anytime for an instant +$10,000 credit injection!
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
