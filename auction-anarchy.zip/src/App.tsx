/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { AuctionLot, UserProfile, ChatMessage, WSMessage, ClientMessage, Collectible } from './types';
import { Header } from './components/Header';
import { LiveAuctionStage } from './components/LiveAuctionStage';
import { AuctionCard } from './components/AuctionCard';
import { LiveWarRoomChat } from './components/LiveWarRoomChat';
import { MintModal } from './components/MintModal';
import { TrophyVaultModal } from './components/TrophyVaultModal';
import { RulesModal } from './components/RulesModal';
import { sound } from './utils/audio';
import { Zap, Flame, Trophy, TrendingDown, Lock, ShieldAlert, Sparkles } from 'lucide-react';

export default function App() {
  // Persistent or generated local user profile
  const [user, setUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('anarchy_user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {}
    }
    const randId = Math.floor(Math.random() * 8999 + 1000);
    return {
      id: `usr-${randId}`,
      name: `CyberPunk#${randId}`,
      handle: `@anarchist_${randId}`,
      avatar: `https://api.dicebear.com/7.x/bottts/svg?seed=User${randId}`,
      balance: 35000,
      wonLots: [],
    };
  });

  const [lots, setLots] = useState<AuctionLot[]>([]);
  const [selectedLotId, setSelectedLotId] = useState<string | null>(null);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [onlineCount, setOnlineCount] = useState<number>(18);
  const [serverTimeOffset, setServerTimeOffset] = useState<number>(0);

  const [activeTab, setActiveTab] = useState<'live' | 'dutch' | 'sealed' | 'vault'>('live');
  const [isMintOpen, setIsMintOpen] = useState(false);
  const [isVaultOpen, setIsVaultOpen] = useState(false);
  const [isRulesOpen, setIsRulesOpen] = useState(false);
  const [isMuted, setIsMuted] = useState(sound.isMuted());
  const [victoryBanner, setVictoryBanner] = useState<{ title: string; price: number } | null>(null);
  const [snipeScreenFlash, setSnipeScreenFlash] = useState(false);

  const wsRef = useRef<WebSocket | null>(null);
  const userRef = useRef(user);
  userRef.current = user;

  // Persist user
  useEffect(() => {
    localStorage.setItem('anarchy_user', JSON.stringify(user));
  }, [user]);

  // WebSocket Connection
  useEffect(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}`;

    let socket: WebSocket;
    let reconnectTimeout: number;

    const connect = () => {
      socket = new WebSocket(wsUrl);
      wsRef.current = socket;

      socket.onopen = () => {
        console.log('Connected to Auction Anarchy server');
      };

      socket.onmessage = (event) => {
        try {
          const msg: WSMessage = JSON.parse(event.data);

          if (msg.type === 'INIT') {
            setLots(msg.payload.lots);
            setOnlineCount(msg.payload.activeUsers);
            setChatMessages(msg.payload.recentChat);
            setServerTimeOffset(msg.payload.serverTime - Date.now());

            if (!selectedLotId && msg.payload.lots.length > 0) {
              const activeBlitz = msg.payload.lots.find((l) => l.type === 'BLITZ' && l.status === 'ACTIVE');
              setSelectedLotId(activeBlitz ? activeBlitz.id : msg.payload.lots[0].id);
            }
          }

          if (msg.type === 'LOTS_UPDATE') {
            setLots(msg.payload.lots);
            setServerTimeOffset(msg.payload.serverTime - Date.now());
          }

          if (msg.type === 'BID_ACCEPTED') {
            const { lotId, lot, bid, snipeTriggered } = msg.payload;

            setLots((prev) =>
              prev.map((l) => (l.id === lotId ? lot : l))
            );

            // Was the user outbid?
            const currentU = userRef.current;
            if (bid.bidderId !== currentU.id) {
              const wasLeading = lot.bids.length > 1 && lot.bids[1]?.bidderId === currentU.id;
              if (wasLeading) {
                sound.playOutbid();
              }
            } else {
              // Deduct from balance
              setUser((prev) => ({
                ...prev,
                balance: Math.max(0, prev.balance - (bid.amount - (lot.bids[1]?.bidderId === currentU.id ? lot.bids[1].amount : 0))),
              }));
            }

            if (snipeTriggered) {
              sound.playSnipeAlert();
              setSnipeScreenFlash(true);
              setTimeout(() => setSnipeScreenFlash(false), 800);
            }
          }

          if (msg.type === 'HAMMER_DROP') {
            const { lotId, winnerName, finalPrice, lot } = msg.payload;
            sound.playGavel();

            setLots((prev) =>
              prev.map((l) => (l.id === lotId ? { ...l, status: 'SOLD', currentPrice: finalPrice } : l))
            );

            // Did the user win?
            if (lot.highestBidderId === userRef.current.id) {
              sound.playVictory();
              confetti({
                particleCount: 120,
                spread: 80,
                origin: { y: 0.6 },
                colors: ['#f59e0b', '#10b981', '#06b6d4', '#ec4899'],
              });

              setVictoryBanner({
                title: lot.collectible.title,
                price: finalPrice,
              });

              setUser((prev) => ({
                ...prev,
                wonLots: [lot.collectible, ...prev.wonLots],
              }));

              setTimeout(() => setVictoryBanner(null), 6000);
            }
          }

          if (msg.type === 'NEW_CHAT') {
            setChatMessages((prev) => [...prev.slice(-49), msg.payload]);
          }

          if (msg.type === 'USER_PRESENCE') {
            setOnlineCount(msg.payload.activeUsers);
          }

          if (msg.type === 'NEW_LOT_LAUNCHED') {
            setLots((prev) => [msg.payload, ...prev]);
          }
        } catch (err) {
          console.error('Error handling WebSocket message:', err);
        }
      };

      socket.onclose = () => {
        reconnectTimeout = window.setTimeout(connect, 2000);
      };

      socket.onerror = () => {
        socket.close();
      };
    };

    connect();

    return () => {
      clearTimeout(reconnectTimeout);
      if (socket) socket.close();
    };
  }, []);

  const sendWS = (msg: ClientMessage) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(msg));
    }
  };

  const handlePlaceBid = (lotId: string, amount: number) => {
    sendWS({
      type: 'PLACE_BID',
      payload: { lotId, amount, user },
    });
  };

  const handleClaimDutch = (lotId: string) => {
    sendWS({
      type: 'CLAIM_DUTCH',
      payload: { lotId, user },
    });
  };

  const handleSubmitSealed = (lotId: string, amount: number) => {
    sendWS({
      type: 'SUBMIT_SEALED_BID',
      payload: { lotId, amount, user },
    });
  };

  const handleSendMessage = (text?: string, reaction?: string) => {
    sendWS({
      type: 'SEND_CHAT',
      payload: { text, reaction, user },
    });
  };

  const handleMintAuction = (data: {
    collectible: Omit<Collectible, 'id' | 'tokenHash'>;
    type: any;
    startingPrice: number;
    durationSeconds: number;
  }) => {
    sendWS({
      type: 'MINT_AUCTION',
      payload: { ...data, user },
    });
  };

  const handleFaucetReload = () => {
    sound.playBid();
    setUser((prev) => ({
      ...prev,
      balance: prev.balance + 10000,
    }));
  };

  const handleToggleMute = () => {
    const muted = sound.toggleMute();
    setIsMuted(muted);
  };

  // Find currently spotlighted lot
  const spotlightLot = lots.find((l) => l.id === selectedLotId) || lots[0];

  // Filter lots based on active tab
  const filteredLots = lots.filter((l) => {
    if (activeTab === 'dutch') return l.type === 'DUTCH';
    if (activeTab === 'sealed') return l.type === 'SEALED_DUEL';
    return true; // 'live' shows all
  });

  return (
    <div className={`min-h-screen bg-[#08090c] text-zinc-100 flex flex-col transition-colors duration-300 ${
      snipeScreenFlash ? 'flash-danger' : ''
    }`}>
      {/* Header */}
      <Header
        user={user}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenMint={() => setIsMintOpen(true)}
        onOpenRules={() => setIsRulesOpen(true)}
        onOpenVault={() => setIsVaultOpen(true)}
        onFaucetReload={handleFaucetReload}
        isMuted={isMuted}
        onToggleMute={handleToggleMute}
        onlineCount={onlineCount}
      />

      {/* Victory Celebration Toast Banner */}
      {victoryBanner && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 p-4 rounded-2xl bg-amber-400 text-black shadow-2xl border-2 border-white flex items-center gap-3 animate-bounce">
          <Trophy className="w-6 h-6 text-black fill-black" />
          <div className="text-sm font-mono">
            <strong>HAMMER DROP VICTORY!</strong> You won <strong>"{victoryBanner.title}"</strong> for ${victoryBanner.price.toLocaleString()}! Added to Trophy Vault.
          </div>
        </div>
      )}

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 lg:px-8 py-6 space-y-8">
        {/* Anti-Snipe Ticker Strip */}
        <div className="flex items-center justify-between px-4 py-2 rounded-xl bg-zinc-900/60 border border-zinc-800 text-xs font-mono text-zinc-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
            <span className="text-zinc-200 font-bold">ANARCHY PROTOCOL:</span>
            <span>Real-time authoritative auctions. Bids in final 10s add +15s Anti-Snipe shield.</span>
          </div>
          <button
            onClick={() => setIsRulesOpen(true)}
            className="hidden sm:inline-block text-amber-400 hover:text-amber-300 underline underline-offset-2"
          >
            How it works
          </button>
        </div>

        {/* Hero Spotlight Stage + War Room Chat */}
        {spotlightLot && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
            {/* Live Center Stage */}
            <div className="lg:col-span-8">
              <LiveAuctionStage
                lot={spotlightLot}
                user={user}
                onPlaceBid={handlePlaceBid}
                serverTimeOffset={serverTimeOffset}
              />
            </div>

            {/* Live War Room Chatter & Emoji Barrage */}
            <div className="lg:col-span-4 flex flex-col">
              <LiveWarRoomChat
                messages={chatMessages}
                user={user}
                onSendMessage={handleSendMessage}
                onlineCount={onlineCount}
              />
            </div>
          </div>
        )}

        {/* Secondary Arena Lots Grid */}
        <section className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-800 pb-3">
            <div className="flex items-center gap-2">
              <Flame className="w-5 h-5 text-amber-400" />
              <h2 className="text-lg font-bold font-display uppercase tracking-tight text-white">
                Active Auction Lots ({filteredLots.length})
              </h2>
            </div>

            {/* Filter Pill Controls */}
            <div className="flex items-center gap-1.5 p-1 bg-zinc-900/80 rounded-lg border border-zinc-800 text-xs font-mono">
              <button
                onClick={() => setActiveTab('live')}
                className={`px-3 py-1 rounded-md transition-colors ${
                  activeTab === 'live' ? 'bg-amber-400 text-black font-bold' : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                All Lots
              </button>
              <button
                onClick={() => setActiveTab('dutch')}
                className={`px-3 py-1 rounded-md transition-colors ${
                  activeTab === 'dutch' ? 'bg-amber-400 text-black font-bold' : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                Dutch Decay
              </button>
              <button
                onClick={() => setActiveTab('sealed')}
                className={`px-3 py-1 rounded-md transition-colors ${
                  activeTab === 'sealed' ? 'bg-amber-400 text-black font-bold' : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                Sealed Duels
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {filteredLots.map((lot) => (
              <AuctionCard
                key={lot.id}
                lot={lot}
                user={user}
                onSelect={(selected) => setSelectedLotId(selected.id)}
                onClaimDutch={handleClaimDutch}
                onSubmitSealed={handleSubmitSealed}
                serverTimeOffset={serverTimeOffset}
              />
            ))}
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="mt-16 border-t border-zinc-900 py-6 px-4 lg:px-8 text-center text-xs font-mono text-zinc-600">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div>
            Auction Anarchy · Fast-paced digital collectible auctions with real-time bidding wars &amp; anti-snipe defenses.
          </div>
          <div className="flex items-center gap-4 text-zinc-500">
            <span>Server Authoritative</span>
            <span>·</span>
            <span>Zero Slop Protocol</span>
            <span>·</span>
            <span>Sub-Second Settlement</span>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <MintModal
        isOpen={isMintOpen}
        onClose={() => setIsMintOpen(false)}
        user={user}
        onMintAuction={handleMintAuction}
      />

      <TrophyVaultModal
        isOpen={isVaultOpen}
        onClose={() => setIsVaultOpen(false)}
        user={user}
      />

      <RulesModal
        isOpen={isRulesOpen}
        onClose={() => setIsRulesOpen(false)}
      />
    </div>
  );
}
