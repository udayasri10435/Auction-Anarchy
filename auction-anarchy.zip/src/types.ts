export type AuctionType = 'BLITZ' | 'DUTCH' | 'SEALED_DUEL';

export type CollectibleRarity = 'COMMON' | 'RARE' | 'LEGENDARY' | 'MYTHIC' | 'CHAOS';

export type VisualTheme =
  | 'cyber-samurai'
  | 'sol-deity'
  | 'neon-drifter'
  | 'void-monolith'
  | 'pixel-punk'
  | 'hyper-cube'
  | 'matrix-skull'
  | 'acid-flower'
  | 'glitch-beast';

export interface Trait {
  label: string;
  value: string | number;
  rarityPercent?: number;
}

export interface BidRecord {
  id: string;
  bidderId: string;
  bidderName: string;
  bidderAvatar: string;
  amount: number;
  timestamp: number;
  isSnipe?: boolean;
}

export interface Collectible {
  id: string;
  title: string;
  series: string;
  edition: string;
  description: string;
  rarity: CollectibleRarity;
  visualTheme: VisualTheme;
  visualSeed: number;
  traits: Trait[];
  creatorName: string;
  creatorAvatar: string;
  tokenHash: string;
}

export interface AuctionLot {
  id: string;
  collectible: Collectible;
  type: AuctionType;
  startingPrice: number;
  currentPrice: number;
  minIncrement: number;
  highestBidderId: string | null;
  highestBidderName: string | null;
  highestBidderAvatar: string | null;
  bids: BidRecord[];
  status: 'UPCOMING' | 'ACTIVE' | 'ENDING_SOON' | 'ENDED' | 'SOLD';
  startsAt: number;
  endsAt: number;
  durationSeconds: number;
  snipeExtensionsCount: number;
  // Specific to Dutch auctions
  dutchFloorPrice?: number;
  dutchDecayPerSec?: number;
  // Specific to Sealed Duels
  blindBidsCount?: number;
  winnerDeclared?: {
    winnerName: string;
    winningAmount: number;
  };
}

export interface UserProfile {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  balance: number;
  wonLots: Collectible[];
}

export interface ChatMessage {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  text?: string;
  reaction?: string;
  timestamp: number;
  isSystemAnnouncement?: boolean;
}

export type WSMessage =
  | { type: 'INIT'; payload: { lots: AuctionLot[]; activeUsers: number; recentChat: ChatMessage[]; serverTime: number } }
  | { type: 'LOTS_UPDATE'; payload: { lots: AuctionLot[]; serverTime: number } }
  | { type: 'BID_ACCEPTED'; payload: { lotId: string; lot: AuctionLot; bid: BidRecord; snipeTriggered: boolean } }
  | { type: 'BID_ERROR'; payload: { lotId: string; reason: string } }
  | { type: 'HAMMER_DROP'; payload: { lotId: string; winnerName: string; finalPrice: number; lot: AuctionLot } }
  | { type: 'NEW_CHAT'; payload: ChatMessage }
  | { type: 'USER_PRESENCE'; payload: { activeUsers: number } }
  | { type: 'NEW_LOT_LAUNCHED'; payload: AuctionLot };

export type ClientMessage =
  | { type: 'PLACE_BID'; payload: { lotId: string; amount: number; user: UserProfile } }
  | { type: 'CLAIM_DUTCH'; payload: { lotId: string; user: UserProfile } }
  | { type: 'SUBMIT_SEALED_BID'; payload: { lotId: string; amount: number; user: UserProfile } }
  | { type: 'SEND_CHAT'; payload: { text?: string; reaction?: string; user: UserProfile } }
  | { type: 'MINT_AUCTION'; payload: { collectible: Omit<Collectible, 'id' | 'tokenHash'>; type: AuctionType; startingPrice: number; durationSeconds: number; user: UserProfile } };
